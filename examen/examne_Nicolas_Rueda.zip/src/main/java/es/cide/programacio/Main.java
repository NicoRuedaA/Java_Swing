package es.cide.programacio;

import com.formdev.flatlaf.FlatLightLaf;

public class Main {
    public static void main(String[] args) {
        // look and fil integral ap pom.xml
        // FlatLightLaf.setup();
        Panel finestra = new Panel();

    }
}
